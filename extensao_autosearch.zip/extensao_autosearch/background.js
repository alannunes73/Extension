
var text = [
  "dropbox",
  "exxon",
  "infomoney",
  "query selector",
  "needforspeed",
  "nanatsu",
  "outlook",
  "investing",
  "twitter",
  "microservices",
  "mercado livre",
  "japan",
  "stanford",
  "callback",
  "network",
  "insta",
  "yahoo",
  "finance",
  "lambda",
  "huawei",
  "ecofriend",
  "spotify",
  "globoplay",
  "food kingdom",
  "apple mac",
  "honda"
];

// another option -> generate random terms
// var text = Array.from({length: 30}, () => Math.random().toString(36).substring(2, 10));

let stopSearch = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) =>
{
  if (request.action === "performRandomSearch") {
    stopSearch = false;
    var cont = 0;
    function createTabAndSearch() {
      if (cont < text.length) {
        let i = cont;
        chrome.tabs.create({url: 'https://www.bing.com'}, (newTab) => {
          chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
            if (tabId == newTab.id && info.status == 'complete') {
              // remove listener
              chrome.tabs.onUpdated.removeListener(listener);

              chrome.scripting.executeScript({
                target: {tabId: newTab.id},
                function: (text, i) => {
                  const searchInput = document.querySelector('#sb_form_q');
                  if (searchInput) {
                    searchInput.focus();
                    let index = 0;

                    function typeCharacter(){
                      let aux = text[i];
                      if (index < aux.length) {
                        searchInput.value += aux[index];
                        searchInput.dispatchEvent(new Event('input', { bubbles: true }));
                        index++;
                        setTimeout(typeCharacter, 150);
                      } else {
                        // submit
                        const form = document.querySelector('#sb_form');
                        if (form) {
                          form.submit();
                        }
                      }
                    }
                    typeCharacter();
                  }          
                },
                args: [text, i]
              });
            }
          });
        });
        cont++;
        setTimeout(createTabAndSearch, 10000);
      }
    }
    createTabAndSearch();
  } else if (request.action === "stopSearch"){
    stopSearch = true;
  }
});


