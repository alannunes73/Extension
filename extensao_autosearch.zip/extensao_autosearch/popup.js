document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("searchButton").addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "performRandomSearch" });
    });

    document.getElementById("exitButton").addEventListener("click", () => {
        chrome.runtime.sendMessage({ action: "stopSearch" });
        window.close();
    });
});